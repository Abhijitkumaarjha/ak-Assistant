import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
DOCS = DATA / "documents"
STYLES = DATA / "style_samples"
REVISIONS = DATA / "revisions"
for p in (DOCS, STYLES, REVISIONS):
    p.mkdir(parents=True, exist_ok=True)

def now():
    return datetime.now(timezone.utc).isoformat()

def write(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")

def read(path):
    return json.loads(path.read_text(encoding="utf-8"))

def save_doc(doc_id, filename, text, chunks):
    write(DOCS / f"{doc_id}.json", {"id":doc_id,"filename":filename,"text":text,"chunks":chunks,"characters":len(text),"uploaded_at":now()})

def get_doc(doc_id):
    p = DOCS / f"{doc_id}.json"
    return read(p) if p.exists() else None

def list_docs():
    out=[]
    for p in DOCS.glob("*.json"):
        try:
            d=read(p); out.append({k:d[k] for k in ("id","filename","characters","uploaded_at","chunks") if k in d})
        except Exception: pass
    return sorted(out,key=lambda d:d.get("uploaded_at",""),reverse=True)

def delete_doc(doc_id):
    p=DOCS/f"{doc_id}.json"
    if p.exists(): p.unlink(); return True
    return False

def save_style(sid,title,text):
    write(STYLES/f"{sid}.json",{"id":sid,"title":title,"text":text,"characters":len(text),"created_at":now()})

def list_styles():
    out=[]
    for p in STYLES.glob("*.json"):
        try:
            d=read(p); out.append({k:d[k] for k in ("id","title","characters","created_at")})
        except Exception: pass
    return sorted(out,key=lambda d:d.get("created_at",""),reverse=True)

def save_revision(rid,payload):
    payload=dict(payload); payload.update({"id":rid,"created_at":now()})
    write(REVISIONS/f"{rid}.json",payload)

def list_revisions():
    out=[]
    for p in REVISIONS.glob("*.json"):
        try:
            d=read(p); out.append({k:d[k] for k in ("id","task","note","created_at") if k in d})
        except Exception: pass
    return sorted(out,key=lambda d:d.get("created_at",""),reverse=True)
