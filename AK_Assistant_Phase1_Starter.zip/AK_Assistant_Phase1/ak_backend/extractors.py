from io import BytesIO
from pathlib import Path

def extract_text(filename: str, raw: bytes) -> str:
    ext = Path(filename).suffix.lower()
    if ext in {".txt", ".md", ".py", ".csv", ".json", ".html"}:
        return raw.decode("utf-8", errors="replace")
    if ext == ".pdf":
        from pypdf import PdfReader
        return "\n\n".join(p.extract_text() or "" for p in PdfReader(BytesIO(raw)).pages)
    if ext == ".docx":
        from docx import Document
        doc = Document(BytesIO(raw))
        lines = [p.text for p in doc.paragraphs if p.text.strip()]
        for table in doc.tables:
            for row in table.rows:
                lines.append(" | ".join(cell.text for cell in row.cells))
        return "\n".join(lines)
    raise ValueError(f"Unsupported file type: {ext}")
