import re, uuid
from pathlib import Path
from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field
from .extractors import extract_text
from .store import save_doc, get_doc, list_docs, delete_doc, save_style, list_styles, save_revision, list_revisions

app = FastAPI(title="AK Assistant API", version="0.1.0",
 description="Phase 1: multiple-file ingestion, evidence retrieval, email templates, writing samples and revisions.")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=False, allow_methods=["*"], allow_headers=["*"])

ALLOWED={".txt",".md",".pdf",".docx",".py",".csv",".json",".html"}
MAX_BYTES=12*1024*1024

class Ask(BaseModel):
    question: str = Field(min_length=3, max_length=3000)
    max_sources: int = Field(default=5, ge=1, le=10)
class Style(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    text: str = Field(min_length=30, max_length=30000)
class Revision(BaseModel):
    task: str = Field(min_length=1, max_length=500)
    original: str = Field(min_length=1, max_length=30000)
    revised: str = Field(min_length=1, max_length=30000)
    note: str = Field(default="", max_length=3000)
class Email(BaseModel):
    recipient: str = Field(default="", max_length=300)
    purpose: str = Field(min_length=3, max_length=1000)
    key_points: list[str] = Field(default_factory=list, max_length=20)
    tone: str = Field(default="professional", max_length=100)
    signoff: str = Field(default="Regards", max_length=100)

def tokens(s):
    stop={"this","that","with","from","have","your","about","what","when","where","which","would","could","should","there","their","then","than","into","also","does","using"}
    return {w for w in re.findall(r"[a-zA-Z0-9][a-zA-Z0-9_'-]{1,}",s.lower()) if w not in stop}

def chunks(text, size=1100, overlap=160):
    text=re.sub(r"\n{3,}","\n\n",text).strip(); out=[]; start=0
    while start<len(text):
        end=min(len(text),start+size)
        if end<len(text):
            b=text.rfind("\n",start+size//2,end)
            if b>start: end=b
        piece=text[start:end].strip()
        if piece: out.append(piece)
        if end>=len(text): break
        start=max(end-overlap,start+1)
    return out

@app.get("/", response_class=HTMLResponse)
def home():
    return """<html><head><title>AK Assistant</title><style>body{font:16px system-ui;max-width:800px;margin:4rem auto;padding:0 1rem;background:#07111f;color:#e8f8ff}a{color:#52e5ff}code{background:#14263a;padding:3px}</style></head><body><h1>AK Assistant backend is running</h1><p>Phase 1 provides file upload, evidence retrieval, email templates, writing sample storage and revision history.</p><p><a href='/docs'>Open interactive API docs</a></p><p>This version is not yet connected to a generative model, does not send emails, and does not run arbitrary code.</p></body></html>"""

@app.get("/api/health")
def health(): return {"status":"ok","service":"AK Assistant","version":"0.1.0"}

@app.post("/api/files/upload")
async def upload(files: list[UploadFile] = File(...)):
    results=[]
    for f in files:
        name=Path(f.filename or "unnamed").name; ext=Path(name).suffix.lower()
        if ext not in ALLOWED:
            results.append({"filename":name,"status":"rejected","reason":f"Unsupported type. Allowed: {', '.join(sorted(ALLOWED))}"}); continue
        raw=await f.read()
        if not raw or len(raw)>MAX_BYTES:
            results.append({"filename":name,"status":"rejected","reason":"Empty file or exceeds 12 MB limit"}); continue
        try: text=extract_text(name,raw)
        except Exception as e:
            results.append({"filename":name,"status":"rejected","reason":f"Text extraction failed: {e}"}); continue
        if not text.strip():
            results.append({"filename":name,"status":"rejected","reason":"No text found; scanned PDFs may need OCR"}); continue
        did=str(uuid.uuid4())[:8]; cs=chunks(text); save_doc(did,name,text,cs)
        results.append({"id":did,"filename":name,"status":"indexed","characters":len(text),"chunks":len(cs)})
    return {"results":results,"documents":list_docs()}

@app.get("/api/files")
def files(): return {"documents":list_docs()}

@app.delete("/api/files/{doc_id}")
def remove_file(doc_id:str):
    if not delete_doc(doc_id): raise HTTPException(404,"Document not found")
    return {"deleted":doc_id}

@app.post("/api/ask")
def ask(req:Ask):
    docs=list_docs()
    if not docs: return {"answer":"No documents indexed yet. Upload files first.","sources":[],"mode":"retrieval-only"}
    qt=tokens(req.question); ranked=[]
    for d in docs:
        full=get_doc(d["id"])
        if not full: continue
        for i,c in enumerate(full["chunks"],1):
            ct=tokens(c); overlap=qt & ct
            if not overlap: continue
            score=len(overlap)/max(1,len(qt)) + .15*len(overlap)/(max(1,len(ct))**.5)
            ranked.append({"score":round(score,4),"source_id":f"{d['id']}-C{i}","filename":d["filename"],"excerpt":c[:1200],"matched_terms":sorted(overlap)})
    ranked.sort(key=lambda x:x["score"],reverse=True); sources=ranked[:req.max_sources]
    if not sources or sources[0]["score"]<.08:
        answer="I couldn't find a sufficiently relevant passage in the uploaded files. Try terms used in the source. I won't invent an answer."
    else:
        answer="Relevant passages found below. This first version retrieves evidence but does not yet synthesize it with a language model. Verify the excerpts before relying on a conclusion.\n\n"
        answer += "\n\n".join(f"[S{i}] {s['filename']} ({s['source_id']})\n{s['excerpt']}" for i,s in enumerate(sources,1))
    return {"answer":answer,"sources":sources,"mode":"retrieval-only"}

@app.post("/api/style-samples")
def add_style(req:Style):
    sid=str(uuid.uuid4())[:8]; save_style(sid,req.title,req.text)
    return {"id":sid,"title":req.title,"characters":len(req.text),"message":"Saved as a reference example; this does not train or fine-tune a model."}

@app.get("/api/style-samples")
def styles(): return {"samples":list_styles()}

@app.post("/api/revisions")
def add_revision(req:Revision):
    rid=str(uuid.uuid4())[:8]; save_revision(rid,req.model_dump())
    return {"id":rid,"message":"Revision saved."}

@app.get("/api/revisions")
def revisions(): return {"revisions":list_revisions()}

@app.post("/api/draft-email")
def email(req:Email):
    greeting=f"Dear {req.recipient.strip()}," if req.recipient.strip() else "Hello,"
    points="\n".join(f"- {p.strip()}" for p in req.key_points if p.strip())
    draft=f"{greeting}\n\nI am writing regarding {req.purpose.strip()}."
    if points: draft+=f"\n\nKey points:\n{points}"
    draft+=f"\n\nPlease let me know if any further information is required.\n\n{req.signoff.strip()},\n[Your name]"
    return {"subject_suggestion":req.purpose.strip().rstrip("."),"draft":draft,"tone_requested":req.tone,"mode":"template","note":"Template only; review before sending."}
