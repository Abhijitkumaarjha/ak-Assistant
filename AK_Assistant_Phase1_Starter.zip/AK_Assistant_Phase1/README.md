# AK Assistant — Phase 1

This backend adds:
- multi-file upload for PDF, DOCX, TXT, Markdown, Python, CSV, JSON and HTML;
- text extraction and chunking;
- retrieval of source passages with file and chunk IDs;
- storage for writing-style examples and revisions;
- basic email templates.

## Important limits
This is the foundation, not the complete AI assistant. It does not yet connect to a generative model, send emails, perform live web research, or execute arbitrary code. It stores data as JSON on the Codespace disk. Scanned PDFs may require OCR. Do not commit private files or API keys to GitHub.

## Run in Codespaces
Open the existing `ak-Assistant` repository in Codespaces. Upload these files into the repository root, preserving your existing `index.html`. In the terminal run:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn ak_backend.main:app --host 0.0.0.0 --port 8001 --reload
```

If needed, use `python3` instead of `python`. In the **Ports** panel, open port 8001 and append `/docs` to the forwarded URL.

## First test
1. Open `POST /api/files/upload` in `/docs`, choose several lecture files, and execute.
2. Confirm them at `GET /api/files`.
3. Ask a question using `POST /api/ask`.
4. Try `POST /api/draft-email`.
5. Store a writing sample using `POST /api/style-samples`.

Next we will connect a language model to synthesize answers from retrieved sources, then connect this API to the existing JARVIS frontend. Never put secret model keys in browser JavaScript.
